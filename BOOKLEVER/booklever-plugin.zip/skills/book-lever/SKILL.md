---
name: book-lever
description: Use when a user wants to summarize, distill, visualize, compare, or apply a nonfiction book using BOOK → LEVER. Supports default “The 10,” deep “Full LEVER,” a specific takeaway deep dive, playbooks, cross-book comparisons, application, and teaching.
---

# BOOK → LEVER: Extract → Distill → Rank → Explain → Visualize → Apply

Transform nonfiction books into clear, accurate, memorable models and practical decisions. Think like a careful reader, strategist and teacher, not a chapter-by-chapter book-report generator.

## How to start
- If user names a nonfiction book with no mode, use **The 10**, the default. Don't demand a mode or a copy of the book.
- If the title or edition is genuinely ambiguous, make a reasonable best effort; ask only when essential.
- If user asks for graphics, produce the graphics when an image-generation capability is available, as well as the accompanying numbered takeaways. Do not present a textual visual *concept* as if an actual image were generated.
- If source is unavailable, distinguish limited verified knowledge from uncertain claims; never invent chapter detail, quotations or studies.

## Source discipline
Find and use primary material (book, excerpt, table of contents, author writing/interviews), verified secondary reviews and user-provided texts where available. Research with browsing when available and helpful, especially for unfamiliar books, disputed facts, editions and publication dates. Cite sources where tool support permits. Never treat a review as proof of a precise statement in the book. Distinguish **author's actual claim**, **fair synthesis** and **your extension**. Label novel diagrams as synthesized models unless from the book. Only quote verbatim when verified; otherwise paraphrase. Do not fabricate anecdotes, statistics or quotations. Flag insufficient source access and contradictions. Don't substitute an unrelated book with a similar title.

## Mode: The 10 (default)
1. **The book in 60 seconds**: central thesis, what problem it addresses, what the author challenges, why it matters (roughly 100–200 words).
2. **The Big Idea**: memorable single sentence and, if helpful, one causal chain.
3. **Top 10 Takeaways**, ranked by importance, actionability, insight and transferability (not chapter order). For each: concise memorable headline; clear explanation; why it matters; concrete example or application; a simple conceptual model. Keep examples explicitly separate from book-derived cases if necessary.
4. **One master framework** representing how the ideas interrelate: chain, flywheel, pyramid, matrix, branching tree or transformation. Explain it briefly and do not force a misleading shape.
5. **What I'd underline 3×**: 1–3 distilled principles (not unverified quotes).
6. **Visual summary**: when requested, generate an infographic of ten numbered panels with accurate brief labels and clear conceptual diagrams; if one panel grid is unreadable, use multiple coherent images. If tool access cannot generate, offer a detailed visual brief without implying the image exists.
End with the next-step question specified below.

## Mode: Full LEVER
Deliver The 10, then deepen without unnecessary repetition:
- **Quotable quotes — the book in the author's words**: collect a compact selection of the most memorable, verified quotations that express the primary ideas. Prefer coverage of distinct core concepts over a large quote count. For each, give the exact short quote, the idea it captures, a brief explanation, and a citation or precise source location (edition/page or chapter when verified; do not invent page numbers). Verify against the book, an authorized excerpt, or an attributable primary source; distinguish an author's interview quote from a passage in the book. Never present a paraphrase as a quotation. Respect applicable quotation and source word limits; for books not supplied by the user, use only brief excerpts within those limits and summarize the remaining ideas in clearly labeled paraphrases. If verified quotations are unavailable, state that limitation and provide labeled paraphrases rather than guessed wording. Include this section in Full LEVER exports as well as chat responses.
- **Contrarian Idea**: conventional assumption / author's argument / explanation.
- **Action playbook**: 5–10 observable actions, immediate vs build-over-time, with optional practical success measures.
- **Critique & caveats**: evidence limitations, where advice fails, changing context, opposing explanations; differentiate strong claims from contextual or overstated claims.
- **Who should read the full book?** Read all / read selected sections / summary captures practical value; explain for which readers.
- **One-page memory map**: thesis, ten very short takeaways, master model, 1–3 key principles, 3–5 actions.
- **Visual summary** on user request, or whenever explicitly part of the chosen task and tools allow it.

## Follow-ups
- **Give me The 10**: The 10 mode; may tighten explanations to user preference.
- **Give me The 3**: thesis, three highest-leverage concepts, three actions.
- **Deep Dive #N**: the selected point with deeper reasoning, evidence, cases, counterexamples, action guidance, visual explanation.
- **Turn it into a Playbook**: operating principles, procedures, checklists, decisions, habits and measurable feedback loops.
- **Compare [book] to [book]**: theses, overlaps, disagreements, assumptions, respective strengths; end with a combined model, preserving irreconcilable differences.
- **Apply this to [scenario]**: for each important idea, map Book Principle → Specific Situation → Recommendation → Expected Effect; distinguish sourced idea from original application.
- **Teach me this book**: progressive mini-masterclass with analogies, questions, and checks for comprehension.
- **Make the visual**: concept graphics or infographic; choose diagrams that carry meaning instead of decoration.

## Visual grammar
Favor arrows, funnels, flywheels, before/after comparisons, ladders, scales, simple matrices, pyramids and icon-led diagrams. Each visual should communicate in ~5 seconds. Clean white/neutral background; accessible high contrast; modern typography; numbered panels; succinct headlines; consistent visual hierarchy. Don't squeeze ten illegible cards into a single image. Check labels, order, spelling and relationship accuracy. If actual graphics are requested, use host image tools if available, not the skill itself as a rendering engine.

## Adapt to genre
- Business/marketing: economics, strategic choices, positioning, execution.
- Psychology: mechanisms, studies, uncertainty, real-world behavior.
- Philosophy: premises, arguments, implications, counterarguments.
- Biography: choices, turning points, contextual lessons; don't generalize an anecdote into proof.
- Leadership: incentives, management, decisions, team systems.
- Self-development: evidence, habits, usable applications vs slogans.
- History: causality, contested perspectives, context and turning points.

## Final quality checks
- **Fidelity**: would the author recognize the thesis and its important caveats?
- **Compression**: will the reader remember the right 20%?
- **Leverage**: what would actually change decisions or actions?
- **Distinctiveness**: are all ten points different and meaningful?
- **Integrity**: is each sourced assertion supportable and each original synthesis clearly signaled?

The objective is maximum *useful insight per minute of attention*: Books → Ideas → Mental Models → Decisions → Action.

## Completion and next-step handoff
After completing each user-facing step or deliverable (The 10, Full LEVER, an infographic, deep dive, playbook, comparison, application, teaching segment, or export), ask one short, explicit question inviting the next step. Recommend the most useful continuation and offer at most 2–3 relevant choices. For example, after The 10 ask whether to create the infographic or expand to Full LEVER; after Full LEVER ask whether to create the infographic, export, or apply the ideas. After an image-only tool result, add the next-step question in the accompanying response when the host permits it. Use plain text choices when interactive controls are unavailable; never expose raw UI code. Complete everything already requested before asking; do not interrupt a requested multi-part task for approval of its already-authorized parts. Do not automatically start an unrequested next step. If the user explicitly wants no follow-up questions, honor that preference.

